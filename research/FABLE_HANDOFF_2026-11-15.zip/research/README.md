# Certifiable FinLM：本地研究工作区

日期：2026-11-15（America/New_York）。基线：公开仓库 `8e4dd0b33c95ac2ac1a6015eba6f2dfafe5c1254`；分支 `research/certifiable`。

本目录将导师材料视为待核验的研究方案，而不是已证明结论。原材料未复制进公开仓库；旧工作区的未提交修改保持原样。所有新增内容仅在本地，未 push、未发 PR、未联系任何外部人员。用户进一步要求不对外联系后，停止新增网络访问，SEC 数据下载未进行。

研究交付入口见 `FABLE_HANDOFF.md` 和 `INDEX.md`。这里只报告实际完成的证明、代码、实验及其限制；不将合成实验当成真实金融语料上的成果。

运行环境可复用原工作区的 `.venv/Scripts/python.exe`。所有脚本均离线；没有隐式下载模型或数据。
