# 离线复现

在本工作区根目录执行；Python 3.12.14、NumPy 2.5.3、PyTorch 2.14.1+cpu 是本次实际环境。理论检查器仅用标准库，评测用NumPy，训练用PyTorch。无需SciPy、GPU、API key或下载。

归档中的 `research/` 可独立解压；从其父目录用 `python research/reproduce.py` 运行新代码。下面旧指标重建命令额外读取原仓库 `docs/experiment-results.md` 的哈希，须在本包注明的基线仓库中执行；现成的重建JSON已随包提供。没有在归档内复制整个旧仓库或任何私有材料。

```powershell
& '..\130U-FinLLM\.venv\Scripts\python.exe' research/reproduce.py
```

重跑四配置三seed合成训练：

```powershell
& '..\130U-FinLLM\.venv\Scripts\python.exe' research/reproduce.py --train
```

其他机器可在已具备上述依赖的环境中把解释器换成 `python`。脚本不自动安装依赖、不联网、不下载权重。原环境路径只是本机便利用法，不包含在可移植代码逻辑内。

旧公开指标的汇总重建：

```powershell
python -m research.evaluation.reconstruct
```

`research/reproduction_log.json` 记录本机检查命令、退出码与输出。理论JSON只是数学组件示例；真实模型、真实解析和可信核心前提未被这些命令验证。合成实验报告的叙事被固定到本轮配置，修改配置后需人工复核结论。

第2轮加入 `certificates/` 的共同分片accuracy/macro-F1检查器和 `planning/` 的精确审计量前沿。集成命令会运行两套新测试、手工票型示例、规划前沿及条件审计链示例。`certificates/` 输入为每个头的类别预测；`planning/` 输入为每类票数，具体schema请读各自README，不能互换。

路径比较轮的独立审查另有标准库检查（不属于前述36项单元测试，也没有重新训练）：

```powershell
python research/paths/review_checks.py
```

标准输出应与 `paths/review_checks.json` 对应：1,008个R1有理可达性例、1,024个D1分层漏检概率例，以及理想条件样本预算。脚本只输出JSON，不修改记录；没有执行R2线性规划，不使用真实模型结果。数学有限检查不替代定理证明。

`theory/notes.tex` 尚未编译；可读证明在 `theory/notes.md`，本包没有冒充编译后的PDF。

本轮未运行原仓库完整训练/全部原有测试，因为未修改原应用代码。只运行与新增研究代码相关的检查。
