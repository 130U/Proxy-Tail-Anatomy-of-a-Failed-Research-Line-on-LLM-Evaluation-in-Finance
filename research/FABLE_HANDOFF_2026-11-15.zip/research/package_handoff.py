"""Build a local review bundle and portable archive; never upload or send."""
import hashlib
import json
import posixpath
import re
from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED


ROOT=Path(__file__).resolve().parent
EXCLUDED={'FABLE_REVIEW_BUNDLE.md','HANDOFF_MANIFEST.json','FABLE_HANDOFF_2026-11-15.zip'}


def files():
    return sorted(p for p in ROOT.rglob('*') if p.is_file() and '__pycache__' not in p.parts
                  and p.suffix != '.pyc' and p.name not in EXCLUDED)


def main():
    description={
        'FABLE_HANDOFF.md':'交接入口与需要导师复核的问题',
        'reports/2026-11-15-round1.md':'自足进展报告、修正和G0/G1状态',
        'claims_audit.md':'46项公开主张审计与文件覆盖',
        'claims_sources.json':'审计来源文件哈希',
        'theory/notes.md':'T0–T3完整假设、证明与反例',
        'theory/notes.tex':'LaTeX理论稿，未编译PDF',
        'theory/independent_review.md':'独立数学复核与限定',
        'literature/literature_review.md':'17条一手证据台账与差异判断',
        'literature/question_status.md':'Q01–Q32完成状态与缺口',
        'literature/local_review.md':'独立代码复核、修复与有限域检查',
        'checks/results.json':'10万点数学检查与有限耦合枚举实际输出',
        'REPRODUCE.md':'本地复现指令和环境',
        'reproduction_log.json':'36项集成测试及第二轮数学检查实际日志',
        'paths/COMPARATIVE_ANALYSIS.md':'五份路径比较、Top3条件建议与保留分歧',
        'paths/PEER_REVIEW.md':'独立AI反方审查、数学核对与修订复核',
        'paths/REVIEW_RESPONSE.md':'七项important回应与尚未关闭的科学门',
        'paths/DECISION_CRITERIA.md':'下一轮可否决阈值及联合样本预算提案',
        'paths/SENIOR_REVIEW_REQUEST.md':'给用户指定资深助手的待发问题包',
        'reports/2026-11-15-round2.md':'集体统计量证书与本地原料盘点增量',
        'reports/completion_audit.md':'全部工作包、32题和G0/G1终态逐项验收',
        'reports/local_data_inventory.md':'真实本地来源元数据与哈希核查，未复制原文',
        'theory/collective_metrics.md':'共同分片下accuracy与macro-F1包络证明',
    }
    rows=['# 研究产出索引', '', '日期均为2026-11-15；新文件仅本地，未发布。下列索引逐文件登记；代码不是已验证的真实金融模型。', '',
          '| 日期 | 编号 | 文件 | 结论或用途 |','|---|---|---|---|']
    for p in files():
        rel=p.relative_to(ROOT).as_posix()
        if rel=='INDEX.md': continue
        if rel.startswith('answers/'):
            code=p.stem; meaning='重点文献题部分完成；子问题缺口见正文'
        elif rel.startswith('paths/'):
            code='路径比较'; meaning='离线候选分析与审查；非已确认原创/真实有效'
        elif rel.startswith('certificates/') or rel.startswith('experiments/collective_metrics/'):
            code='CM1–CM5'; meaning='共同分片统计量条件证书；构造输入非真实模型'
        elif rel.startswith('planning/'):
            code='T1.4/规划'; meaning='固定零发现条件的最小审计量；非序贯有效'
        elif rel.startswith('experiments/wp0_1/') or rel.startswith('evaluation/'):
            code='WP0.1'; meaning='汇总重建/簇评测；真实三基线仍缺失'
        elif rel.startswith('theory/') or rel.startswith('checks/'):
            code='WP0.3'; meaning='条件数学命题与健全性检查'
        elif rel.startswith('xbrl/'):
            code='WP0.4'; meaning='受限离线样例；无真实时间戳证书'
        elif rel.startswith('local/') or rel.startswith('experiments/local_foundations/'):
            code='WP0.2/0.5/T1.4'; meaning='合成世界、消融与精确审计计算'
        else: code='交接'; meaning='本地研究材料'
        rows.append(f'| 2026-11-15 | {code} | [{rel}]({rel}) | {description.get(rel,meaning)} |')
    rows += ['| 2026-11-15 | 打包 | [FABLE_REVIEW_BUNDLE.md](FABLE_REVIEW_BUNDLE.md) | 主要材料合并阅读版 |',
             '| 2026-11-15 | 打包 | [HANDOFF_MANIFEST.json](HANDOFF_MANIFEST.json) | 文件清单与SHA256，不含清单自身 |',
             '| 2026-11-15 | 打包 | [FABLE_HANDOFF_2026-11-15.zip](FABLE_HANDOFF_2026-11-15.zip) | 本地可移植归档，无权重或私有数据 |']
    (ROOT/'INDEX.md').write_text('\n'.join(rows)+'\n',encoding='utf-8')
    order=['FABLE_HANDOFF.md','paths/COMPARATIVE_ANALYSIS.md',
           'paths/PATH_01_audited_information_set.md','paths/PATH_02_numeric_sensitivity.md',
           'paths/PATH_03_audit_design_frontier.md','paths/PATH_04_dependence_robust_risk.md',
           'paths/PATH_05_proof_carrying_numeric_reasoning.md',
           'paths/PEER_REVIEW.md','paths/REVIEW_RESPONSE.md','paths/DECISION_CRITERIA.md',
           'paths/INDEPENDENT_CHALLENGES.md','paths/SENIOR_REVIEW_REQUEST.md','paths/STUDY_CHARTER.md',
           'reports/2026-11-15-round2.md','reports/completion_audit.md','reports/local_data_inventory.md',
           'theory/collective_metrics.md','experiments/collective_metrics/report.md',
           'planning/record.md','literature/collective_review.md',
           'reports/2026-11-15-round1.md','INDEX.md','theory/notes.md',
           'theory/independent_review.md','claims_audit.md','literature/literature_review.md',
           'literature/question_status.md',*[f'answers/Q{q}.md' for q in ['03','10','13','29','30','31','32']],
           'experiments/wp0_1/record.md','experiments/local_foundations/report.md','checks/record.md',
           'xbrl/record.md','literature/local_review.md','REPRODUCE.md']
    parts=['# Fable 路径分析与研究进展复核包\n\n包含五份分析、独立AI审查与回应、第二轮数学结果及第一轮记录。这是本地阶段性交付，非已完成的真实金融模型或论文；资深助手问题包尚未发送。\n']
    for rel in order:
        p=ROOT/rel
        if not p.exists(): raise FileNotFoundError(p)
        content=p.read_text(encoding='utf-8')
        def links(match):
            target=match.group(2)
            if '://' in target or target.startswith(('#','/')): return match.group(0)
            rewritten=posixpath.normpath(posixpath.join(posixpath.dirname(rel),target))
            return f'[{match.group(1)}]({rewritten})'
        content=re.sub(r'\[([^\]]+)\]\(([^)]+)\)',links,content)
        parts.append(f'\n\n---\n\n<!-- source: {rel} -->\n\n'+content)
    bundle=ROOT/'FABLE_REVIEW_BUNDLE.md'
    bundle.write_text(''.join(parts),encoding='utf-8')
    payload=files()+[bundle]
    manifest=dict(date='2026-11-15',base_commit='8e4dd0b33c95ac2ac1a6015eba6f2dfafe5c1254',
                  branch='research/certifiable',status='round2_and_five_path_review_handoff; G0/G1 not passed',
                  network_policy='offline since explicit user steering; no publication or external messages',
                  files=[dict(path=p.relative_to(ROOT).as_posix(),bytes=p.stat().st_size,
                              sha256=hashlib.sha256(p.read_bytes()).hexdigest()) for p in payload])
    mf=ROOT/'HANDOFF_MANIFEST.json'; mf.write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf-8')
    archive=ROOT/'FABLE_HANDOFF_2026-11-15.zip'
    with ZipFile(archive,'w',ZIP_DEFLATED) as z:
        for p in payload+[mf]: z.write(p,'research/'+p.relative_to(ROOT).as_posix())
    with ZipFile(archive) as z:
        assert z.testzip() is None
        for f in manifest['files']:
            assert hashlib.sha256(z.read('research/'+f['path'])).hexdigest()==f['sha256']
    print(json.dumps(dict(files=len(payload)+1,archive_bytes=archive.stat().st_size,
                          bundle_bytes=bundle.stat().st_size,archive_sha256=hashlib.sha256(archive.read_bytes()).hexdigest()),indent=2))


if __name__=='__main__': main()
